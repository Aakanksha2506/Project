/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

class Student {
    private String name;
    private ArrayList<Integer> grades;

    public Student(String name) {
        this.name = name;
        this.grades = new ArrayList<>();
    }

    public void addGrade(int grade) {
        grades.add(grade);
    }

    public double getAverageGrade() {
        if (grades.isEmpty()) {
            return 0.0;
        }
        int sum = 0;
        for (int grade : grades) {
            sum += grade;
        }
        return sum / (double) grades.size();
    }

    public String getName() {
        return name;
    }

    public ArrayList<Integer> getGrades() {
        return grades;
    }
}

public class GradeTracker {
    private HashMap<String, Student> students;
    private Scanner scanner;

    public GradeTracker() {
        students = new HashMap<>();
        scanner = new Scanner(System.in);
    }

    public void addStudent() {
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        students.put(name, new Student(name));
        System.out.println("Student " + name + " added.");
    }

    public void addGrade() {
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        Student student = students.get(name);
        if (student != null) {
            System.out.print("Enter grade: ");
            int grade = scanner.nextInt();
            scanner.nextLine();  // consume the newline
            student.addGrade(grade);
            System.out.println("Grade added for " + name);
        } else {
            System.out.println("Student not found.");
        }
    }

    public void displayStudentAverage() {
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        Student student = students.get(name);
        if (student != null) {
            System.out.println("Average grade for " + name + ": " + student.getAverageGrade());
        } else {
            System.out.println("Student not found.");
        }
    }

    public void displayAllStudents() {
        for (Student student : students.values()) {
            System.out.println("Student: " + student.getName());
            System.out.println("Grades: " + student.getGrades());
            System.out.println("Average grade: " + student.getAverageGrade());
        }
    }

    public void menu() {
        int choice;
        do {
            System.out.println("\n1. Add Student");
            System.out.println("\n2. Add Grade");
            System.out.println("\n3. Display Student Average");
            System.out.println("\n4. Display All Students");
            System.out.println("\n5. Exit");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // consume the newline

            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    addGrade();
                    break;
                case 3:
                    displayStudentAverage();
                    break;
                case 4:
                    displayAllStudents();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    public static void main(String[] args) {
        GradeTracker tracker = new GradeTracker();
        tracker.menu();
    }
}
